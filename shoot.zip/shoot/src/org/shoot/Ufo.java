package org.shoot;

import java.util.Random;

public class Ufo extends FlyingObject implements Award{
	/**�������˶�*/
	private int xSpeed = 1; 
	private int ySpeed = 2;
	/**�������� 0 1 */
	private int awardType;	
	
	public Ufo() {
		life = 2;
		this.image = ShootGame.ufo;
		width = image.getWidth();
		height = image.getHeight();
		Random rand = new Random(); //���Ufo���ֵ�λ��
		x = rand.nextInt(ShootGame.WIDTH-this.width);
		y = -this.height;
		awardType = rand.nextInt(2); //�������0 1
	}

	@Override
	public int getType() {
		// TODO Auto-generated method stub
		Random rand = new Random();
		awardType = rand.nextInt(2);
		return awardType;
	}
	
	@Override
	public void step() {
		x += xSpeed;
		y += ySpeed;
		if(x >= ShootGame.WIDTH-this.width){
			xSpeed = -1;
		}
		if(x <= 0){
			xSpeed = 1;
		}
	}
	
	@Override
	public boolean outOfBounds() {
		// TODO Auto-generated method stub
		return this.y >= ShootGame.HEIGHT;
	}

	public int getLife() {
		return this.life;
	}

	public void setLife(int life) {
		this.life = life;
	}
}
