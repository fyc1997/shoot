package org.shoot;

import java.util.Random;

/**�л�*/
public class Airplane2 extends FlyingObject implements Enemy,Award{
	private int speed = 4; //�л��߲��Ĳ���
	
	public Airplane2() {
		life = 5;
		this.image = ShootGame.airplane2;
		width = image.getWidth();
		height = image.getHeight();
		Random rand = new Random(); //����л����ֵ�λ��
		x = rand.nextInt(ShootGame.WIDTH-this.width);
		y = -this.height;
	}

	@Override
	public int getScore() {
		// TODO Auto-generated method stub
		return 10; //���һ���л������
	}

	public void setLife(int life) {
		this.life = life;
	}
	
	public int getLife(){
		return this.life;
	}

	@Override
	public void step() {
		y += speed;
	}

	@Override
	public boolean outOfBounds() {
		// TODO Auto-generated method stub
		return this.y >= ShootGame.HEIGHT;
	}

	@Override
	public int getType() {
		// TODO Auto-generated method stub
		return 1;
	}
}
