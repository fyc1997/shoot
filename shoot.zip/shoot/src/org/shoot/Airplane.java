package org.shoot;

import java.util.Random;

/**�л�*/
public class Airplane extends FlyingObject implements Enemy{
	private int speed = 4; //�л��߲��Ĳ���
	
	public Airplane() {
		life = 1;
		this.image = ShootGame.airplane;
		width = image.getWidth();
		height = image.getHeight();
		Random rand = new Random(); //����л����ֵ�λ��
		x = rand.nextInt(ShootGame.WIDTH-this.width);
		y = -this.height;
	}

	@Override
	public int getScore() {
		// TODO Auto-generated method stub
		return 5; //���һ���л������
	}

	@Override
	public void step() {
		y += speed;
	}

	@Override
	public boolean outOfBounds() {
		// TODO Auto-generated method stub
		return this.y >= ShootGame.HEIGHT;
	}

	@Override
	public int getLife() {
		// TODO Auto-generated method stub
		return this.life;
	}

	public void setLife(int life) {
		this.life = life;
	}
}
